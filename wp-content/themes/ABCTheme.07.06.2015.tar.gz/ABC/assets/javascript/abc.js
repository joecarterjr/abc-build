
var $j = jQuery.noConflict();

$j(function(){
    $j('#menu-main-navigation').slicknav({label:''});

/*$j(".work-home img").each(function() {

    $j(this).parent().parent().append($j("<div class='post-hover'/>").text($j(this).attr("title")).hide());
      

}).hover(function(){

$j(".post-hover").show();
},function(){
$j(".post-hover").hide();
}
        );
*/

});